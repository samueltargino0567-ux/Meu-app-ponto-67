package com.example.gamebooster

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.Switch
import android.widget.TextView

class OverlayService : Service() {
    private lateinit var wm: WindowManager
    private var root: View? = null
    private val stats = Stats()
    private val handler = Handler(Looper.getMainLooper())
    @Volatile private var alive = false
    private lateinit var tvCpu: TextView
    private lateinit var tvGpu: TextView
    private lateinit var tvTemp: TextView

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        if (!Settings.canDrawOverlays(this)) { stopSelf(); return }
        startAsForeground()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        buildPanel()
        alive = true
        Thread {
            while (alive) {
                val s = stats.read()
                handler.post { render(s) }
                Thread.sleep(1000)
            }
        }.start()
    }

    private fun startAsForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("gb", "Game Booster", NotificationManager.IMPORTANCE_LOW))
        val n = Notification.Builder(this, "gb")
            .setContentTitle("Game Booster ativo")
            .setContentText("Painel flutuante em execução")
            .setSmallIcon(android.R.drawable.ic_menu_manage)
            .build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(1, n)
        }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun label(size: Float = 14f) = TextView(this).apply {
        setTextColor(Color.WHITE); textSize = size
    }

    private fun buildPanel() {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(12), dp(14), dp(12))
            background = GradientDrawable().apply {
                setColor(Color.argb(215, 16, 16, 28)); cornerRadius = dp(18).toFloat()
                setStroke(dp(1), Color.argb(90, 61, 242, 224))
            }
        }
        tvCpu = label(); tvGpu = label(); tvTemp = label()
        val sw = Switch(this).apply {
            text = "Manter em segundo plano"; setTextColor(Color.WHITE); textSize = 13f
            setOnCheckedChangeListener { _, on ->
                val pkg = packageName
                Thread {
                    if (on) Sh.run("cmd deviceidle whitelist +$pkg; cmd appops set $pkg RUN_IN_BACKGROUND allow; am set-standby-bucket $pkg active")
                    else Sh.run("cmd deviceidle whitelist -$pkg")
                }.start()
            }
        }
        val close = label(13f).apply {
            text = "Fechar painel"; setTextColor(Color.rgb(61, 242, 224))
            setPadding(0, dp(8), 0, 0)
            setOnClickListener { stopSelf() }
        }
        box.addView(tvCpu); box.addView(tvGpu); box.addView(tvTemp); box.addView(sw); box.addView(close)

        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = dp(16); y = dp(80) }

        var sx = 0; var sy = 0; var tx = 0f; var ty = 0f
        box.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { sx = lp.x; sy = lp.y; tx = e.rawX; ty = e.rawY }
                MotionEvent.ACTION_MOVE -> {
                    lp.x = sx + (e.rawX - tx).toInt(); lp.y = sy + (e.rawY - ty).toInt()
                    wm.updateViewLayout(box, lp)
                }
            }
            true
        }
        wm.addView(box, lp)
        root = box
        render(Stats.Snap(null, null, null))
    }

    private fun render(s: Stats.Snap) {
        tvCpu.text = "CPU  " + (s.cpu?.let { "$it%" } ?: "--")
        tvGpu.text = "GPU  " + (s.gpu?.let { "$it%" } ?: "indisponível")
        tvTemp.text = "Temp CPU  " + (s.temp?.let { "%.1f °C".format(it) } ?: "--")
        tvTemp.setTextColor(if ((s.temp ?: 0f) >= 70f) Color.rgb(255, 120, 120) else Color.WHITE)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int) = START_STICKY

    override fun onDestroy() {
        alive = false
        root?.let { try { wm.removeView(it) } catch (e: Throwable) {} }
        super.onDestroy()
    }
}
