package com.example.gamebooster

import android.app.Activity
import android.app.ActivityManager
import android.app.AlertDialog
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.Uri
import android.os.BatteryManager
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.StatFs
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import rikka.shizuku.Shizuku

class MainActivity : Activity() {
    private lateinit var status: TextView
    private lateinit var info: TextView
    private val permListener = Shizuku.OnRequestPermissionResultListener { _, _ -> runOnUiThread { refresh() } }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        try { Shizuku.addRequestPermissionResultListener(permListener) } catch (e: Throwable) {}

        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(32), dp(20), dp(32))
        }
        col.addView(TextView(this).apply { text = "Game Booster"; textSize = 26f; setTextColor(Color.BLACK) })
        status = TextView(this).apply { textSize = 15f; setPadding(0, dp(8), 0, dp(8)) }
        col.addView(status)

        col.addView(btn("Conceder permissão do Shizuku") {
            if (!Sh.running()) toast("Abra o Shizuku e inicie o serviço primeiro")
            else try { Shizuku.requestPermission(1) } catch (e: Throwable) { toast("Falha: ${e.message}") }
        })
        col.addView(btn("Abrir painel flutuante") { openPanel() })
        col.addView(btn("Parar painel") { stopService(Intent(this, OverlayService::class.java)) })

        col.addView(section("Desempenho"))
        col.addView(btn("Limpar apps em segundo plano") { shell("am kill-all") })
        col.addView(btn("Escolher jogo (modo desempenho)") { pickGame() })
        col.addView(btn("Desempenho sustentado (Android 12+)") { shell("cmd power set-fixed-performance-mode-enabled true") })
        col.addView(btn("Reduzir animações") {
            shell("settings put global window_animation_scale 0.5; settings put global transition_animation_scale 0.5; settings put global animator_duration_scale 0.5")
        })
        col.addView(btn("Não matar apps em segundo plano (Android 12+)") {
            shell("settings put global settings_enable_monitor_phantom_procs false; device_config set_sync_disabled_for_tests persistent; device_config put activity_manager max_phantom_processes 2147483647")
        })
        col.addView(btn("Desfazer ajustes") {
            shell("cmd power set-fixed-performance-mode-enabled false; settings put global window_animation_scale 1.0; settings put global transition_animation_scale 1.0; settings put global animator_duration_scale 1.0")
        })

        col.addView(section("Informações do aparelho"))
        info = TextView(this).apply { textSize = 15f; setTextColor(Color.DKGRAY) }
        col.addView(info)

        setContentView(ScrollView(this).apply { addView(col) })
    }

    override fun onResume() { super.onResume(); refresh() }

    override fun onDestroy() {
        try { Shizuku.removeRequestPermissionResultListener(permListener) } catch (e: Throwable) {}
        super.onDestroy()
    }

    private fun btn(t: String, onClick: () -> Unit) = Button(this).apply {
        text = t; isAllCaps = false; setOnClickListener { onClick() }
    }

    private fun section(t: String) = TextView(this).apply {
        text = t; textSize = 18f; setTextColor(Color.BLACK); setPadding(0, dp(20), 0, dp(4))
    }

    private fun toast(m: String) = Toast.makeText(this, m, Toast.LENGTH_LONG).show()

    private fun shell(cmd: String) {
        if (!Sh.granted()) { toast("Conceda a permissão do Shizuku primeiro"); return }
        Thread {
            val out = Sh.run(cmd)
            runOnUiThread { toast(if (out.isBlank()) "Pronto" else out.take(200)) }
        }.start()
    }

    private fun openPanel() {
        if (!Sh.granted()) { toast("Conceda a permissão do Shizuku primeiro"); return }
        if (!Settings.canDrawOverlays(this)) {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            toast("Permita \"Exibir sobre outros apps\" e toque de novo"); return
        }
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission("android.permission.POST_NOTIFICATIONS") != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf("android.permission.POST_NOTIFICATIONS"), 2)
        }
        startForegroundService(Intent(this, OverlayService::class.java))
    }

    private fun pickGame() {
        val pm = packageManager
        val apps = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
            .map { it.loadLabel(pm).toString() to it.activityInfo.packageName }
            .sortedBy { it.first.lowercase() }
        AlertDialog.Builder(this).setTitle("Escolha o jogo")
            .setItems(apps.map { it.first }.toTypedArray()) { _, i ->
                shell("cmd game set --mode performance ${apps[i].second}")
            }.show()
    }

    private fun refresh() {
        status.text = when {
            Sh.granted() -> "Shizuku: conectado e autorizado"
            Sh.running() -> "Shizuku: rodando, falta conceder permissão"
            else -> "Shizuku: não está rodando. Abra o app Shizuku e inicie."
        }
        status.setTextColor(if (Sh.granted()) Color.rgb(0, 130, 90) else Color.rgb(190, 60, 40))

        val mi = ActivityManager.MemoryInfo()
        (getSystemService(ACTIVITY_SERVICE) as ActivityManager).getMemoryInfo(mi)
        val sf = StatFs(Environment.getDataDirectory().path)
        val bat = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val lvl = bat?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale = bat?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
        val bt = (bat?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) ?: 0) / 10f
        val gb = 1024.0 * 1024 * 1024
        val soc = if (Build.VERSION.SDK_INT >= 31) Build.SOC_MODEL else Build.HARDWARE

        info.text = listOf(
            "Modelo: ${Build.MANUFACTURER} ${Build.MODEL}",
            "Android: ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})",
            "Chip: $soc",
            "Núcleos de CPU: ${Runtime.getRuntime().availableProcessors()}",
            "RAM: %.1f GB (livre %.1f GB)".format(mi.totalMem / gb, mi.availMem / gb),
            "Armazenamento: %.0f GB (livre %.0f GB)".format(sf.totalBytes / gb, sf.availableBytes / gb),
            "Bateria: ${lvl * 100 / scale}% · %.1f °C".format(bt),
            "Tela: ${resources.displayMetrics.widthPixels}x${resources.displayMetrics.heightPixels} px"
        ).joinToString("\n")
    }
}
