package com.example.gamebooster

class Stats {
    data class Snap(val cpu: Int?, val gpu: Int?, val temp: Float?)

    private var lastTotal = 0L
    private var lastIdle = 0L

    private val cmd = "head -1 /proc/stat; echo '##G'; " +
        "for f in /sys/class/kgsl/kgsl-3d0/gpu_busy_percentage /sys/kernel/gpu/gpu_busy " +
        "/sys/class/misc/mali0/device/utilisation /sys/devices/platform/*.mali/utilization; " +
        "do [ -r \"\$f\" ] && { cat \"\$f\"; break; }; done; echo '##T'; " +
        "for z in /sys/class/thermal/thermal_zone*; do " +
        "echo \"\$(cat \$z/type 2>/dev/null) \$(cat \$z/temp 2>/dev/null)\"; done"

    fun read(): Snap {
        val out = Sh.run(cmd)
        val g = out.indexOf("##G")
        val t = out.indexOf("##T")
        if (g < 0 || t < 0) return Snap(null, null, null)

        val nums = out.substring(0, g).trim().split(Regex("\\s+")).drop(1).mapNotNull { it.toLongOrNull() }
        var cpu: Int? = null
        if (nums.size >= 5) {
            val idle = nums[3] + nums[4]
            val total = nums.sum()
            if (lastTotal > 0 && total > lastTotal) {
                val used = 1.0 - (idle - lastIdle).toDouble() / (total - lastTotal)
                cpu = (used * 100).toInt().coerceIn(0, 100)
            }
            lastTotal = total
            lastIdle = idle
        }

        val gpu = Regex("\\d+").find(out.substring(g + 3, t))?.value?.toIntOrNull()?.coerceIn(0, 100)

        val zones = out.substring(t + 3).lines().mapNotNull { line ->
            val parts = line.trim().split(" ")
            if (parts.size < 2) return@mapNotNull null
            val raw = parts.last().toFloatOrNull() ?: return@mapNotNull null
            val v = if (raw > 1000) raw / 1000f else raw
            if (v < 10f || v > 120f) null else parts.dropLast(1).joinToString(" ").lowercase() to v
        }
        val cpuZones = zones.filter { it.first.contains("cpu") }
        val others = zones.filter { Regex("soc|tsens|mtk|cluster|big|little").containsMatchIn(it.first) }
        val temp = (cpuZones.ifEmpty { others }).maxOfOrNull { it.second }

        return Snap(cpu, gpu, temp)
    }
}
